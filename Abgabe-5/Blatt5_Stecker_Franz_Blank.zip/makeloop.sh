#!/bin/bash
while [ True ]
do
	wait && make tex
done
